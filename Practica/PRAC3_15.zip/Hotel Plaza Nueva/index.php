<html>
    <head>
        <?php include 'include/head.php'; ?>
    </head>
    <body onload="MatchHeight();">
		<!-- Header -->
        <?php 
            include 'include/navbar.php';
            include 'include/content.php'; 
        ?> 

	</body>
</html>