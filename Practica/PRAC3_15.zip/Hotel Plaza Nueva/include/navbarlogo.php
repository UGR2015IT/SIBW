<?php 
    echo '<div id="logo">';
    echo '<span class="image avatar48"><img src="images/logo.png" alt="Logo" /></span>';
    echo "<h1 id='title'>";
    echo "Hotel Plaza Nueva";
    echo "</h1>";
    echo '<p>Granada</p>';
    echo '</div>';
?>