<?php
    //Server Address
    $SmtpServer="ssl://smtp.gmail.com";
    $SmtpPort="465"; //default
    $SmtpUser="mynewmailfortests@gmail.com";
    $SmtpPass="#";
?>